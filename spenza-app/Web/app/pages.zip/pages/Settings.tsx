import { useState } from "react";
import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Lock, Unlock, EyeOff, ShieldAlert, Save } from "lucide-react";
import { useAppContext } from "../context/AppContext";

export function Settings() {
  const navigate = useNavigate();
  const { isHiddenTransactionsEnabled, setIsHiddenTransactionsEnabled, hiddenPasswordHash, setHiddenPasswordHash } = useAppContext();
  
  const [enabled, setEnabled] = useState(isHiddenTransactionsEnabled);
  const [password, setPassword] = useState("");
  
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsHiddenTransactionsEnabled(enabled);
    if (enabled && password) {
      setHiddenPasswordHash(password); // in a real app, hash this!
    } else if (!enabled) {
      setHiddenPasswordHash(null);
    }
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex justify-center items-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-slate-900/60 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-2xl"
      >
        <div className="flex items-center gap-4 mb-8">
          <button 
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold">Settings</h1>
        </div>

        <form className="space-y-6" onSubmit={handleSave}>
          <div className="bg-slate-800/50 p-5 rounded-2xl border border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg">
                  <EyeOff className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold">Hidden Transactions</h3>
                  <p className="text-xs text-slate-400">Enable private mode</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer" 
                  checked={enabled}
                  onChange={(e) => setEnabled(e.target.checked)}
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
              </label>
            </div>

            {enabled && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="space-y-4 pt-4 border-t border-slate-700"
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-400">Password for Hidden Transactions</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-slate-500" />
                    </div>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={hiddenPasswordHash ? "••••••••" : "Set a password"}
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                      required={!hiddenPasswordHash}
                    />
                  </div>
                </div>
                
                <p className="text-xs text-amber-400 flex items-center gap-1">
                  <ShieldAlert className="w-4 h-4" /> This password will be required to view hidden transactions.
                </p>
              </motion.div>
            )}
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-2xl py-4 flex items-center justify-center gap-2 transition-colors shadow-lg shadow-blue-500/20"
          >
            <Save className="w-5 h-5" />
            Save Settings
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}