import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Coffee, Home, ShoppingBag, Car, Smartphone, Search, Filter, Edit2, EyeOff, Trash2, Eye } from "lucide-react";
import { useAppContext, iconMap } from "../context/AppContext";

export function Transactions() {
  const navigate = useNavigate();
  const { transactions, setTransactions } = useAppContext();
  const [searchQuery, setSearchQuery] = useState("");
  
  const handleDeleteTransaction = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    setTransactions(transactions.filter(tx => tx.id !== id));
  };

  const handleHideTransaction = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    setTransactions(transactions.map(tx => tx.id === id ? { ...tx, isHidden: true } : tx));
  };

  const visibleTransactions = transactions
    .filter(t => !t.isHidden)
    .filter(t => 
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      t.category.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6 md:p-10">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate("/dashboard")}
              className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-2xl font-bold">All Transactions</h1>
          </div>
          <button className="bg-slate-900 border border-slate-800 text-slate-300 p-2 rounded-xl hover:bg-slate-800 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-500" />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search transactions..." 
            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>

        <div className="bg-slate-900/40 border border-slate-800/80 rounded-3xl p-6 backdrop-blur-md">
          {visibleTransactions.length === 0 ? (
             <div className="text-center py-10 text-slate-500">
               No transactions found.
             </div>
          ) : (
            <div className="space-y-4">
              <AnimatePresence>
                {visibleTransactions.map((tx, i) => {
                  const Icon = iconMap[tx.iconName] || Coffee;
                  return (
                    <motion.div 
                      key={tx.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -50 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center justify-between p-4 rounded-2xl hover:bg-slate-800/50 transition-colors group cursor-pointer border border-transparent hover:border-slate-700/50 relative"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${tx.bg} ${tx.color}`}>
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-semibold text-slate-200 group-hover:text-white transition-colors">{tx.name}</p>
                          <p className="text-xs text-slate-500">{tx.date}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {/* Hover Actions */}
                        <div className="hidden group-hover:flex items-center gap-2 mr-2">
                          <button 
                            className="p-2 text-slate-400 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={(e) => handleHideTransaction(e, tx.id)}
                            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-400/10 rounded-lg transition-colors"
                            title="Hide"
                          >
                            <EyeOff className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={(e) => handleDeleteTransaction(e, tx.id)}
                            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-400/10 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="text-right">
                          <p className={`font-bold ${tx.amount > 0 ? 'text-emerald-400' : 'text-white'}`}>
                            {tx.amount < 0 ? '-' : '+'}${Math.abs(tx.amount).toFixed(2)}
                          </p>
                          <p className="text-xs text-slate-500">{tx.category}</p>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}